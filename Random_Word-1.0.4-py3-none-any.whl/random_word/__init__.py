from .random_word import RandomWords

__name__ = "Random Word"
__author__ = "Vaibhav Singh <hi@vaibhavsingh97.com>"
__version__ = '1.0.4'
